# semiconductor

please see the read me in [github pages](http://mk8j.github.io/semiconductor/)


