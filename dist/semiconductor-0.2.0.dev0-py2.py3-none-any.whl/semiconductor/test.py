'''
This doesn't work, can get nested dictionaries to work
'''


from glob import glob
import yaml as yaml

try:
    import ConfigParser as configparser
except:
    import configparser

import sys


def convert():

    for fname in glob('**/**/*.defect*'):
        print(fname)
        lst = []
        Models = configparser.ConfigParser()
        Models.read(fname)

        for i in Models.sections():
            dic = {}
            # print(i, type(i))

            for key in Models[i]:
                # print(key)
                dic[key] = Models[i][key]

            lst.append({i: dic})

        print(lst)

        with open(fname.split('.')[0] + '.yaml', 'w+') as f:
            yaml.dump_all(lst, f, default_flow_style=False,
                          indent=4, default_style='')


def remote_yaml2files():
    import os
    for fname in glob('**/**/*.model*'):
        os.remove(fname)


def test():
    fname = 'D:\Dropbox\CommonCode\semiconductor\src\semiconductor\electrical\Si\ionisation.yaml'
    dic = {}
    with open(fname, 'r') as f:
        for i in yaml.load_all(f):
            dic.update(i)

    print(dic.keys())


convert()
